function openNav() {
  
  document.getElementById("mySidenav").style.width="100%";
}
function closeNav() {
  document.getElementById('mySidenav').style.width="";
}

let enterEL1 = document.getElementById("enter-el1")
let enterEL2 = document.getElementById("enter-el2")
let enterEL3 = document.getElementById("enter-el3")
let enterEL4 = document.getElementById("enter-el4")

let sendEL = document.getElementById("send-el")
let nameEL = document.getElementById("name-el")
let emailEL = document.getElementById("email-el")
let numberEL = document.getElementById("number-el")
let messageEL = document.querySelector(".message-el")
let changeBG = document.getElementById("change-bg")
let bodyEL = document.getElementById("body-el")
nameEL.addEventListener("click",()=>{
  
  enterEL1.innerHTML = "Enter name"
} )

emailEL.addEventListener("click",()=>{
  
  enterEL2.innerHTML = "Enter email"
} )

numberEL.addEventListener("click",()=>{
  
  enterEL3.innerHTML = "Enter number"
  
} )
messageEL.addEventListener("click",()=>{
  
  enterEL4.innerHTML = "Enter message"
} )
 
 let warning1 = document.getElementById("warning1");
  let warning2 = document.getElementById("warning2");
   let warning3 = document.getElementById("warning3");
 
 function warn1(){
   let x = nameEL.value;
    if (x == "" || x == null) {
      alert("Add a Name");
      nameEL.style.border ="1px solid red";
      warning1.style.color = "red";
      warning1.style.display ="block";
      warning1.style.fontStyle ="normal";
      return false;
    
    } 
 }
 function warn2(){
    let y = emailEL.value;
    if (y == "" || y == null) {
      alert("Add an Email");
      emailEL.style.border = "1px solid red";
      warning2.style.color = "red";
      warning2.style.display = "block";
      warning2.style.fontStyle = "normal";
      return false;
}
 }
 
  function warn3(){
    let z = numberEL.value;
    if (z == "" || z == null) {
      alert("Add a Number");
      numberEL.style.border = "1px solid red";
      warning3.style.color = "red";
      warning3.style.display = "block";
      warning3.style.fontStyle = "normal";
      return false;
}
}
sendEL.addEventListener("click", () => {
warn1()
warn2()
warn3()
 
})

let homePage = document.getElementById("home-page");
let home = document.getElementById("home");
let nft = document.getElementById("nft");

let nftPage = document.getElementById("nft-page");
nftPage.addEventListener("click", ()=>{
  home.style.display ="none";
  nft.style.display = "flex"
  update.style.display ="none";
  sourceCode.style.display ="none";
  
})
homePage.addEventListener("click", () => {
  
  home.style.display= "block";
  nft.style.display ="none";
  update.style.display="none";
  sourceCode.style.display ="none";
})
let update = document.getElementById("update");
let updatePage = document.getElementById("update-page");

updatePage.addEventListener("click", () => {
      home.style.display = "none";
      update.style.display ="flex";
      nft.style.display="none";

    }
)

let sourceCode = document.getElementById("sourceCode");
let sourceCodePage = document.getElementById("sourceCode-page");
sourceCodePage.addEventListener("click", () => {
      home.style.display = "none";
      update.style.display ="none";
      nft.style.display="none";
      sourceCode.style.display ="flex";

    }
)